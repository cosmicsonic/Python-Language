import dis

with open("simple.pyc", "rb") as f:
  data = f.read()

dis.dis(data)