#!/bin/env python3

from lark import *
import sys, operator


with open("grammar.lark", 'r') as f:
  simple_grammar = f.read()

if len(sys.argv) > 1:
  with open(sys.argv[1], 'r') as f:
    code = f.read()
else:
  with open("fizz.cool", 'r') as f:
    code = f.read()

parser = Lark(simple_grammar)

tree = parser.parse(code)
variables = {}

def handleCompare(expression):
  number1 = getValue(expression.children[0])
  operation = expression.children[1].data
  number2 = getValue(expression.children[2])

  if operation == "compare_lt":
    func = operator.lt
  elif operation == "compare_eq":
    func = operator.eq
  elif operation == "compare_gt":
    func = operator.gt
  return func(number1, number2)
    
def getValue(value):
  if value.type == "INTEGER":
    result = int(value.value)
  elif value.type == "SYMBOL":
    result = variables[value.value]
  elif value.type == "STRING":
    result = value.value.replace('"', '')
  elif value.type == "BOOL":
    result = [False, True][value.value == "true"]

  return result

def handleInstructions(instructions):
  for inst in instructions:
    if inst.data == "equal":
      name = inst.children[0].value
      value = inst.children[1]
      variables[name] = getValue(value)
    elif inst.data == "print":
      value = inst.children[0]
      print(getValue(value))
    elif inst.data == "inc":
      name = inst.children[0].value
      variables[name] += 1
    elif inst.data == "dec":
      name = inst.children[0].value
      variables[name] -= 1
      
    elif inst.data == "if_stmt":
      check = inst.children[0]
      if_true = inst.children[1]
      has_else = False
      if isinstance(check, Tree):
        boolean = handleCompare(check)
      else:
        boolean = getValue(check)
  
      if len(inst.children) == 3:
        has_else = True
        else_stmt = inst.children[2]
      
      if boolean:
        handleInstructions(if_true.children)
      elif boolean == False and has_else:
        handleInstructions(else_stmt.children)
        
    elif inst.data == "loop":
      variable_name = inst.children[0].value
      start = int(inst.children[1].value)
      end = int(inst.children[2].value)
      body = inst.children[3:]
      for i in range(start, end):
        variables[variable_name] = i
        handleInstructions(body)
      del variables[variable_name]

handleInstructions(tree.children)    