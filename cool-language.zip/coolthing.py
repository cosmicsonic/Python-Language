import dis, marshal
from bytecode import ConcreteInstr, ConcreteBytecode

# code = """
# print("hello", "byte")
# a = 1
# print(a)
# """

# c = compile(code, "", "exec")

names = ["print", "a"]
consts = ["joel is cool", 'foobar', None]
instructions = [
  ConcreteInstr("LOAD_NAME", 0),
  ConcreteInstr("LOAD_CONST", 1),
  ConcreteInstr("CALL_FUNCTION", 1),
  ConcreteInstr("LOAD_CONST", 2),
  ConcreteInstr("RETURN_VALUE")
]

bytecode = ConcreteBytecode()
bytecode.names = names
bytecode.consts = consts
bytecode.extend(instructions)

exec(bytecode.to_code())

magic = [int("0d", 16), int("55", 16), 10, 13, 00, 3, 0, 0, 0, 133, 10, 71, 98, 12, 0, 0, 0]
header = b''.join([i.to_bytes(1, 'big') for i in magic])

with open("foo.pyc", 'wb') as f:
    result = marshal.dumps(bytecode.to_code())
    f.write(header+result)