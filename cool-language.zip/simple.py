print("hello")
a = 1
print(a)